package com.example.restapi1.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.example.restapi1.entities.Course;

@Service
public class CourseImpl implements CourseService {

	List<Course> list;

	public CourseImpl() {
		list = new ArrayList<>();
		list.add(new Course(1, "Java", "java is good"));
		list.add(new Course(2, "C", "C is good"));
	}

	@Override
	public List<Course> getCourses() {
		// TODO Auto-generated method stub
		return list;
	}

	@Override
	public Course getCourse(long courseId) {
		// TODO Auto-generated method stub
	  Course c=null;
	  for(Course course:list) {
		  if(course.getCourseid()==courseId) {
			  c=course;
		  }
	  }
		return c;
	}
		
	
	@Override
	public Course addCourse(Course course) {
		// TODO Auto-generated method stub
		list.add(course);
		return course;
	}
	
	// Method 1 for update
	/*
	 * @Override public Course updateCourse(Course course) { // TODO Auto-generated
	 * method stub
	 * 
	 * list.forEach(e->{ if(e.getCourseid()==course.getCourseid()) {
	 * e.setDescription(course.getDescription()); e.setName(course.getName()); } });
	 * 
	 * return course; }
	 */

	
	  // Method 2 for update
	@Override
	public Course updateCourse(Course course) {
		Course c = null;
		for (Course e : list) {
			if (e.getCourseid()==course.getCourseid()) {
				 e.setDescription(course.getDescription());
				 e.setName(course.getName());
				c = course;
				break;
			}
		}
		return c;
			
	}
// for delete 
	@Override
	public void deleteCourse(long parseLong) {

		list=this.list.stream().filter(e->e.getCourseid()!=parseLong).collect(Collectors.toList());
		
	}
	@Override
	public List <Course> getCourseByName(String courseName) {
	     
	return list.stream().filter((e)->e.getName().equals(courseName)).collect(Collectors.toList());
		
	}

}
