package com.example.restapi1.entities;

public class Course {
	private long courseid;
	private String name;
	private String description;
	public long getCourseid() {
		return courseid;
	}
	public void setCourseid(long courseid) {
		this.courseid = courseid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Course(long courseid, String name, String description) {
		super();
		this.courseid = courseid;
		this.name = name;
		this.description = description;
	}
	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Course [courseid=" + courseid + ", name=" + name + ", description=" + description + ", getCourseid()="
				+ getCourseid() + ", getName()=" + getName() + ", getDescription()=" + getDescription()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	

}
