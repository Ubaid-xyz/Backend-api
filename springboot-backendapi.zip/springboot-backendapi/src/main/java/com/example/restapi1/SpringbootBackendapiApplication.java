package com.example.restapi1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootBackendapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootBackendapiApplication.class, args);
	}

}
